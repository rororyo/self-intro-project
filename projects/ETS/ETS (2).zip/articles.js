$("#article h1").fadeOut(0).fadeIn(1000);
$("#article .article-image").fadeOut(0).fadeIn(1000);
$("#article p").fadeOut(0).fadeIn(1000);
$("#article h2").fadeOut(0).fadeIn(1000);